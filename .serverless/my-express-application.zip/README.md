# Networker-Server
Networker app serverless architecture back-end


App based on Serverless and AWS FaaS - experimenting with new technologies on back - end ;)
